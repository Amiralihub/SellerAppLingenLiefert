
package com.example.sellapplingen;
public class CaptureActivity extends com.journeyapps.barcodescanner.CaptureActivity {

}
